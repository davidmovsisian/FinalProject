from contextlib import asynccontextmanager
from fastapi import FastAPI
from config import settings
from models import PropertyListing, InsightResponse
from rag_service import RAGService
import requests

rag_service = RAGService()

@asynccontextmanager
async def lifespan(_: FastAPI):
    rag_service.initialize()
    yield

app = FastAPI(title=settings.app_name, lifespan=lifespan)

@app.get("/health")
def health() -> dict[str, object]:
    return {
        "status": "ok",
        "vector_count": rag_service.collection_size(),
    }

# @app.post("/retrieve")
# def retrieve(request: InsightRequest) -> RetrieveResponse:
#     try:
#         listing = request.to_listing()
#     except ValueError as exc:
#         raise HTTPException(status_code=422, detail=str(exc)) from exc

#     similar = rag_service.retrieve_listings(listing, k=settings.top_k)
#     return RetrieveResponse(similar_listings=similar)


# @app.post("/add")
# def add_listing(request: InsightRequest) -> AddListingResponse:
#     try:
#         listing = request.to_listing()
#     except ValueError as exc:
#         raise HTTPException(status_code=422, detail=str(exc)) from exc

#     listing_id = rag_service.add_listing(listing)
#     return AddListingResponse(success=True, listing_id=listing_id)

@app.post("/create-insight")
def create_insight(listing: PropertyListing) -> InsightResponse:
    api_url = settings.ai_assistant_api_url.strip()
    if not api_url:
        return  "AI Assistant API URL is not configured."
    similar = rag_service.retrieve_listings(listing, k=settings.top_k)
    payload = {
        "listing": listing.model_dump(),
        "similar_listings": [s.model_dump() for s in similar],
    }
    response = requests.post(api_url, json=payload)
    insight = response.json().get("insight", "")
    listing_id = rag_service.add_listing(listing)

    return InsightResponse(listing_id=listing_id, similar_listings=similar, insight=insight)