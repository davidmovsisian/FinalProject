from pydantic import BaseModel, Field
from typing import Any, List, Optional

class RoomCondition(BaseModel):
    type: str = Field(min_length=1)
    condition_score: int = Field(ge=1, le=5)
    confidence: float = Field(ge=0, le=1)

class PropertyListing(BaseModel):
    property_type: str = Field(min_length=1)
    location: str = Field(min_length=1)
    price: str = Field(min_length=1)
    rooms_number: int = Field(ge=0)
    features: list[str] = Field(default_factory=list)
    conditions: list[RoomCondition] = Field(default_factory=list)

class SimilarListing(BaseModel):
    id: str
    distance: float
    listing: PropertyListing

class InsightResponse(BaseModel):
    listing_id: str
    similar_listings: list[SimilarListing]
    insight: str

class HistoryMessage(BaseModel):
    role: str            # "user" or "assistant"
    content: Any = None  # str normally; list of blocks in Gradio 6 multimodal


class ChatRequest(BaseModel):
    history: Optional[List[HistoryMessage]] = None
    message: Optional[str] = None


class ChatResponse(BaseModel):
    response: str